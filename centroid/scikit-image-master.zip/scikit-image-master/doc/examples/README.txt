.. _examples_gallery:

General examples
-------------------

General-purpose and introductory examples for the scikit.

